/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatappprogpoe;

/**
 * Login class handles user registration, login, and welcome message logic.
 * *Date: April 2025
 *
 * Note: Some methods were created with the guidance of ChatGPT (OpenAI, 2025)
 * for educational purposes as part of a Programming Portfolio of Evidence.
 *
 * Reference:
 *
 *
 *
 *
 *
 * Title: Java Scanner Class
 *
 * Author: W3Schools
 *
 * Date Accessed: 19 April 2025
 *
 * Version: N/A
 *
 * Available: https://www.w3schools.com/java/java_user_input.asp
 *
 */
import java.util.Scanner;

public class Login {

    // Private instance variables to store user credentials and login state
    private String username;
    private String password;
    private String cellNumber;
    private boolean LoggedIn = false;

    // Scanner for user input
    Scanner scanner = new Scanner(System.in);

    /**
     * Checks whether the username meets the required format. Username must
     * contain an underscore and be no more than 5 characters.
     */
    public boolean checkUserName(String username) {
        if(username.contains("_") && username.length() <= 5) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Validates password complexity. Must contain a capital letter, a number, a
     * special character, and be 8+ characters long. * Code Attribution:
     *
     * Title: Java Regular Expressions - Java Regex
     *
     * Author: Oracle
     *
     * Date Accessed: 19 April 2025
     *
     * Version: Java SE 8
     *
     * Available:
     * https://docs.oracle.com/javase/8/docs/api/java/util/regex/Pattern.html
     *
     *
     */
    public boolean checkPasswordComplexity(String password) {
    if (password.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$")) {
        return true;
    } else {
        return false;
    }
}


    /**
     * Validates the format of the cell phone number. Must include international
     * code and be structured as +27 followed by 9 digits.
     */
    public boolean checkCellPhoneNumber(String number) {
    if (number.matches("^\\+27\\d{9}$")) {
        return true;
    } else {
        return false;
    }
}
    /**
     * Handles user registration. Prompts for username, password, and cell
     * number and validates each input.
     */
     /**
         *
         * Title: How to Validate Phone Numbers in Java
         *
         * Author: Baeldung
         *
         * Date Accessed: 19 April 2025
         *
         * Version: N/A
         *
         * Available: https://www.baeldung.com/java-regex-validate-phone-numbers
         */
    public String registerUser() {
        System.out.print("Enter username: ");
        username = scanner.nextLine();

        if (!checkUserName(username)) {
            return "Username is not correctly formatted. Please ensure that your username contains an underscore and is no more than five characters in length.";
        }

        System.out.print("Enter password: ");
        password = scanner.nextLine();

        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted; please ensure it contains at least eight characters, a capital letter, a number, and a special character.";
        }

        // Debug line: check if we're reaching here
        System.out.println("Reached phone number prompt");

        System.out.print("Enter cell number (e.g., +27XXXXXXXXX): ");
        cellNumber = scanner.nextLine();
        if (!checkCellPhoneNumber(cellNumber)) {
            return "Cell number is not correctly formatted. Please enter a valid South African number starting with +27 and followed by 9 digits.";
        }

        return "User successfully registered!\nUsername and password captured successfully.\nCell number added.";
    }

    /**
     * Captures user input for login and checks it against stored credentials.
     */
    public String captureLogin() {
        System.out.print("Enter username: ");
        String inputUsername = scanner.nextLine();

        System.out.print("Enter password: ");
        String inputPassword = scanner.nextLine();

        LoggedIn = inputUsername.equals(username) && inputPassword.equals(password);

        return LoggedIn ? "Login successful." : "Login failed. Incorrect username or password.";
    }

    /**
     * Displays a personalized welcome message if the user is logged in.
     */
    public String getWelcomeMessage() {
        System.out.print("Enter your first name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter your last name: ");
        String lastName = scanner.nextLine();

        return LoggedIn
                ? "Welcome " + firstName + " " + lastName + ", it is great to see you again."
                : "You are not logged in. Cannot display welcome message.";
    }

}
