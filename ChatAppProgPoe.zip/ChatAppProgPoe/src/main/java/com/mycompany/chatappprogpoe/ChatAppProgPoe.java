/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.chatappprogpoe;

/**
 * This is the main class that runs the chat app program. It calls methods from
 * the Login class to handle registration and login.
 *
 * Code Attribution:
 *
 * Title: Java Regular Expressions - Java Regex
 *
 * Author: Oracle
 *
 * Date Accessed: 19 April 2025
 *
 * Version: Java SE 8
 *
 * Available:
 * https://docs.oracle.com/javase/8/docs/api/java/util/regex/Pattern.html
 *
 *
 *
 * Title: Java Scanner Class
 *
 * Author: W3Schools
 *
 * Date Accessed: 19 April 2025
 *
 * Version: N/A
 *
 * Available: https://www.w3schools.com/java/java_user_input.asp
 *
 *
 *
 * Title: How to Validate Phone Numbers in Java
 *
 * Author: Baeldung
 *
 * Date Accessed: 19 April 2025
 *
 * Version: N/A
 *
 * Available: https://www.baeldung.com/java-regex-validate-phone-numbers
 */
public class ChatAppProgPoe {

    public static void main(String[] args) {
        // Creating an object of Login to access its methods
        Login app = new Login();

        // Calling the method to register a user and printing the response
        System.out.println("=== REGISTRATION ===");
        System.out.println(app.registerUser());

        // Calling the method to allow login and printing the response
        System.out.println("\n=== LOGIN ===");
        System.out.println(app.captureLogin());

        // Displaying the welcome message after successful login
        System.out.println("\n=== WELCOME MESSAGE ===");
        System.out.println(app.getWelcomeMessage());
    }
}
