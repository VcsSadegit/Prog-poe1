/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.chatappprogpoe;

import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Nqobile
 */
public class LoginTest {

    private Login login;

    @BeforeEach
    public void setUp() {
        login = new Login();
    }

    @Test
    public void testCheckUserName_Valid() {
        assertTrue(login.checkUserName("ab_c"));
    }

    @Test
    public void testCheckUserName_Invalid_NoUnderscore() {
        assertFalse(login.checkUserName("abcde"));
    }

    @Test
    public void testCheckUserName_Invalid_TooLong() {
        assertFalse(login.checkUserName("abc_de"));
    }

    @Test
    public void testCheckPasswordComplexity_Valid() {
        assertTrue(login.checkPasswordComplexity("Password1!"));
    }

    @Test
    public void testCheckPasswordComplexity_Invalid_NoUppercase() {
        assertFalse(login.checkPasswordComplexity("password1!"));
    }

    @Test
    public void testCheckPasswordComplexity_Invalid_NoNumber() {
        assertFalse(login.checkPasswordComplexity("Password!"));
    }

    @Test
    public void testCheckPasswordComplexity_Invalid_NoSpecialChar() {
        assertFalse(login.checkPasswordComplexity("Password1"));
    }

    @Test
    public void testCheckPasswordComplexity_Invalid_TooShort() {
        assertFalse(login.checkPasswordComplexity("P1!a"));
    }

    @Test
    public void testCheckCellPhoneNumber_Valid() {
        assertTrue(login.checkCellPhoneNumber("+27812345678"));
    }

    @Test
    public void testCheckCellPhoneNumber_Invalid_MissingPlus() {
        assertFalse(login.checkCellPhoneNumber("27812345678"));
    }

    @Test
    public void testCheckCellPhoneNumber_Invalid_TooShort() {
        assertFalse(login.checkCellPhoneNumber("+2781234567"));
    }

    @Test
    public void testCheckCellPhoneNumber_Invalid_TooLong() {
        assertFalse(login.checkCellPhoneNumber("+278123456789"));
    }
}
